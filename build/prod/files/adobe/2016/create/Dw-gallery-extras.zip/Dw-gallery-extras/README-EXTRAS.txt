Read the following before using the files within this archive.

1. This archive contains files that belong to the article:
Ten steps to building a photo gallery website with Adobe Dreamweaver CC

Use these files to preview a completed view of the tutorial assets including
extra slideshow features. Try to deconstruct the files to add to your project.

2. Unpack the archive and put the files in the following locations:

* Extract the Dw-gallery-extras.zip file to your desktop or any location on your hardrive.

